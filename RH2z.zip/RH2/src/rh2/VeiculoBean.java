package rh2;

public class VeiculoBean {
   private int cod_veic;
   private int n_doc;
   private int id_func;
   private String modelo;
   private String placa;
   private String cor;
   private String data_retirada;
   private String data_devolucao;
   
   public VeiculoBean(int cod_veic, int n_doc,int id_func, String modelo,String placa,String cor, String data_retirada, String data_devolucao) {
       this.cod_veic= cod_veic;
       this.n_doc = n_doc;
       this.id_func = id_func;
       this.modelo = modelo;
	   this.placa = placa;
	   this.cor = cor;
	   this.data_retirada = data_retirada;
	   this.data_devolucao = data_devolucao;
   }

    public int getCod_veic() {
        return cod_veic;
    }

    public void setCod_veic(int cod_veic) {
        this.cod_veic = cod_veic;
    }

    public int getN_doc() {
        return n_doc;
    }

    public void setN_doc(int n_doc) {
        this.n_doc = n_doc;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
	
	 public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }
	
	 public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }
   
    public int getId_func() {
        return id_func;
    }

   
    public void setId_func(int id_func) {
        this.id_func = id_func;
    } 
    
	public String getData_retirada() {
        return data_retirada;
    }

   
    public void setData_retirada(String data_retirada) {
        this.data_retirada = data_retirada;
    }   
    public String getData_devolucao() {
        return data_devolucao;
    }

   
    public void setData_devolucao(String data_devolucao) {
        this.data_devolucao = data_devolucao;
    }   	
   
    public String toString(){
        return "\nCodigo Veiculo: "+cod_veic+"\nNumero Documentacao: "+n_doc+"\nModelo: "+modelo+"\nPlaca: "+placa+"\nCor: "+cor+"\nID Funcionario: "+id_func+"\nData Retirada: "+data_retirada+"\nData Devolucao: "+data_devolucao;
    }
}
