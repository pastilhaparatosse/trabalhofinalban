package rh2;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class FuncionarioModel {

    public static void create(FuncionarioBean a, Connection con) throws SQLException {
        PreparedStatement st;
            st = con.prepareStatement("INSERT INTO funcionario (nome,id_func,carteirat,contrato,id_gerente,id_supervisor) VALUES (?,?,?,?,?,?)");
            st.setString(1, a.getNome());
            st.setInt(2, a.getId_func());
            st.setInt(3, a.getCarteirat());
	    st.setInt(4, a.getContrato());
            st.setInt(5, a.getId_gerente());
            st.setInt(6, a.getId_supervisor());
            st.execute();
            st.close();  
    }

    static HashSet listAll(Connection con) throws SQLException {
        Statement st;
        HashSet list = new HashSet();
            st = con.createStatement();
            String sql = "SELECT nome,id_func,carteirat,contrato,id_gerente,id_supervisor FROM funcionario";
            ResultSet result = st.executeQuery(sql);
            while(result.next()) {
                list.add(new FuncionarioBean(result.getString(1), result.getInt(2), result.getInt(3),result.getInt(4),result.getInt(5),result.getInt(6)));
            }
        return list;
    }
    
    static HashSet listMax(Connection con) throws SQLException {
        Statement st;
        HashSet list = new HashSet();
            st = con.createStatement();
            String sql = "SELECT nome,id_func,carteirat,contrato,id_gerente,id_supervisor FROM funcionario WHERE id_func IN (SELECT MAX(id_func) FROM funcionario)";
            ResultSet result = st.executeQuery(sql);
            while(result.next()) {
                list.add(new FuncionarioBean(result.getString(1), result.getInt(2), result.getInt(3),result.getInt(4),result.getInt(5),result.getInt(6)));
            }
        return list;
    }
    
    static HashSet listAllWithVeiculo(Connection con) throws SQLException {
        Statement st;
        HashSet list = new HashSet();
        st = con.createStatement();
        String sql = "SELECT nome,f.id_func,carteirat,contrato,id_gerente,id_supervisor,cod_veic,n_doc,modelo,placa,cor,data_retirada,data_devolucao"
                +    " FROM funcionario f NATURAL JOIN veiculo v ";
        ResultSet result = st.executeQuery(sql);
        while(result.next()) {
            FuncionarioBean mb = new FuncionarioBean(result.getString(1), result.getInt(2), result.getInt(3),
                    result.getInt(4), result.getInt(5), result.getInt(6));
            VeiculoBean a = new VeiculoBean(result.getInt(7),result.getInt(8),result.getInt(2),result.getString(9),result.getString(10),result.getString(11),result.getString(12),result.getString(13));
            mb.setVeiculo(a);
            list.add(mb);
        }
        return list;
    }
}


 