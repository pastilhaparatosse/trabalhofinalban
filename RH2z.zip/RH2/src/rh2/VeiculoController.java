package rh2;

import rh2.VeiculoBean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class VeiculoController {
    
    public void createVeiculo(Connection con) throws SQLException {
        Scanner input = new Scanner(System.in);
        System.out.println("Insira os seguintes dados para a criar um novo empréstimo de Veiculo: ");
        System.out.print("Codigo:  ");
        int cod_veic = input.nextInt();
        System.out.print("Numero Documento:  ");
        int n_doc = input.nextInt();
		System.out.print("ID Funcionario:  ");
        int id_func = input.nextInt();
        System.out.print("Modelo:  ");
        String modelo = input.next();
		System.out.print("Placa:  ");
        String placa = input.next();
		System.out.print("Cor:  ");
        String cor = input.next();
		System.out.print("Data Retirada:  ");
        String data_retirada = input.next();
		System.out.print("Data Devolucao:  ");
        String data_devolucao = input.next();
		VeiculoBean ab = new VeiculoBean(cod_veic,n_doc,id_func,modelo,placa,cor,data_retirada,data_devolucao);
        VeiculoModel.create(ab, con);
        System.out.println("\nEmprestimo criado com sucesso!!");
    }

    void listarVeiculo(Connection con) throws SQLException {
        HashSet all = VeiculoModel.listAll(con);
        Iterator<VeiculoBean> it = all.iterator();
        while(it.hasNext()) {
            System.out.println(it.next().toString());
        }
    }
}
