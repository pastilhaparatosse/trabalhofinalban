package rh2;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class FuncionarioController {
    
    public void createFuncionario(Connection con) throws SQLException {
        Scanner input = new Scanner(System.in);
        System.out.println("Insira os seguintes dados para a criar um novo funcionario:  ");
        System.out.print("Nome:  ");
        String nome = input.next();
        System.out.print("ID Funcionario:  ");
        int id_func = input.nextInt();
        System.out.print("Carteira de trabalho:  ");
        int carteirat = input.nextInt();
	System.out.print("Contrato:  ");
        int contrato = input.nextInt();
	System.out.print("ID Gerente:  ");
        int id_gerente = input.nextInt();
	System.out.print("ID Supervisor:  ");
        int id_supervisor = input.nextInt();
        FuncionarioBean ab = new FuncionarioBean(nome,id_func,carteirat,contrato,id_gerente,id_supervisor);
        FuncionarioModel.create(ab, con);
        System.out.println("\nFuncionario criado com sucesso!!");
    }
    
     void listarFuncionario(Connection con) throws SQLException {
        HashSet all = FuncionarioModel.listAll(con);
        Iterator<FuncionarioBean> it = all.iterator();
        while(it.hasNext()) {
            System.out.println(it.next().toString());
        }
    }
     
     void listarmaxFuncionario (Connection con)throws SQLException {
         HashSet all = FuncionarioModel.listMax(con);
         Iterator<FuncionarioBean> it = all.iterator();
        while(it.hasNext()) {
            System.out.println(it.next().toString());
     }
     }

    void listarFuncionarioVeiculo(Connection con) throws SQLException {
        HashSet all = FuncionarioModel.listAllWithVeiculo(con);
        Iterator<FuncionarioBean> it = all.iterator();
        while(it.hasNext()) {
            System.out.println(it.next().toString());
        }
    }
}
