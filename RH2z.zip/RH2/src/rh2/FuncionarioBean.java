package rh2;


public class FuncionarioBean {
   private String nome;
   private int id_func;
   private int carteirat;
   private int contrato;
   private int id_gerente;
   private int id_supervisor;
   private VeiculoBean veiculo;
   
   public FuncionarioBean(String nome, int id_func, int carteirat, int contrato, int id_gerente, int id_supervisor) {
       this.nome = nome;
       this.id_func = id_func;
       this.carteirat = carteirat;
       this.contrato = contrato;
       this.id_gerente = id_gerente;
       this.id_supervisor = id_supervisor;
   }

   public VeiculoBean getVeiculo(){
       return veiculo;
   }
   
   public void setVeiculo(VeiculoBean veiculo){
       this.veiculo=veiculo;
   }
           
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

  
    public int getId_func() {
        return id_func;
    }

   
    public void setId_func(int id_func) {
        this.id_func = id_func;
    }

   
    public int getCarteirat() {
        return carteirat;
    }

   
    public void setCarteirat(int carteirat) {
        this.carteirat = carteirat;
		
    }
    public int getContrato() {
        return contrato;
    }

    
    public void setContrato(int contrato) {
        this.contrato = contrato;
    }
	 public int getId_gerente() {
        return id_gerente;
    }

        public void setId_gerente(int id_gerente) {
        this.id_gerente = id_gerente;
    }
	public int getId_supervisor() {
        return id_supervisor;
    }

    public void setId_supervisor(int id_supervisor) {
        this.id_supervisor = id_supervisor;
    }
    public String toString(){
        StringBuffer sb = new StringBuffer();
        String text = null;
        sb.append ("\nNome: "+nome+"\nID Funcionario: "+id_func+"\nNumero Carteira: "+carteirat+"\nContrato: "+contrato+"\nID Gerente: "+id_gerente+"\nID Supervisor: "+id_supervisor);
        if (veiculo != null){
        sb.append  ("\nCodigo Veiculo: "+veiculo.getCod_veic()+"\nNumero Documentacao: "+veiculo.getN_doc()+"\nModelo: "+veiculo.getModelo()+"\nPlaca: "+veiculo.getPlaca()+"\nCor: "+veiculo.getCor()+"\nID Funcionario: "+veiculo.getId_func()+"\nData Retirada: "+veiculo.getData_retirada()+"\nData Devolucao: "+veiculo.getData_devolucao()); 
        }
        return sb.toString();
    }

   /* void setVeiculo(VeiculoBean a) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }*/
}