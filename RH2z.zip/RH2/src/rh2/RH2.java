package rh2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class RH2 {

    public static void main(String[] args) throws SQLException {
        Conexao c = new Conexao();
        Connection con = c.getConnection();
        int op = 0;
        do{
            op = menu();
            try {
                switch (op) {
                    case 1: new VeiculoController().createVeiculo(con);
                            break;
                    case 2: new VeiculoController().listarVeiculo(con);
                            break;
		    case 3: new FuncionarioController().createFuncionario(con);
                            break;
                    case 4: new FuncionarioController().listarFuncionario(con);
                            break;
		    case 5: new FuncionarioController().listarFuncionarioVeiculo(con);
                            break;
                    case 6: new FuncionarioController().listarmaxFuncionario(con);
                   }
            }catch(SQLException ex) {
               
                System.out.println(ex.getMessage());
                continue;
            }
        } while(op>0 && op<7);  
        con.close();
    }    
    
    private static int menu() {
        System.out.println("");
        System.out.println("Informe o numero da opcao que deseja efetuar: ");
        System.out.println("1 - Inserir um novo registro de emprestimo de veiculo");
        System.out.println("2 - Exibir todos os emprestimos de veiculos");
	System.out.println("3 - Inserir um novo funcionario");
        System.out.println("4 - Exibir todos os funcionarios");
	System.out.println("5 - Listar todos os funcionarios que ja emprestaram algum veiculo");
        System.out.println("6 - Listar as informacoes do funcionario com o maior numero de ID");
        System.out.println("Digite qualquer outro valor para sair");
        System.out.print("Sua opcao: ");
        Scanner input = new Scanner(System.in);
        return input.nextInt();
    }
}
