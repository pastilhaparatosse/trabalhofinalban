package rh2;


import rh2.VeiculoBean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class VeiculoModel {

    public static void create(VeiculoBean a, Connection con) throws SQLException {
        PreparedStatement st;
            st = con.prepareStatement("INSERT INTO veiculo (cod_veic,n_doc,id_func,modelo,placa,cor,data_retirada,data_devolucao) VALUES (?,?,?,?,?,?,?,?)");
            st.setInt(1, a.getCod_veic());
            st.setInt(2, a.getN_doc());
	    st.setInt(3, a.getId_func());
            st.setString(4, a.getModelo());
	    st.setString(5, a.getPlaca());
	    st.setString(6, a.getCor());
	    st.setString(7, a.getData_retirada());
	    st.setString(8, a.getData_devolucao());
			
            st.execute();
            st.close();  
    }

    static HashSet listAll(Connection con) throws SQLException {
        Statement st;
        HashSet list = new HashSet();
            st = con.createStatement();
            String sql = "SELECT cod_veic,n_doc,id_func,modelo,placa,cor,data_retirada,data_devolucao FROM veiculo";
            ResultSet result = st.executeQuery(sql);
            while(result.next()) {
                list.add(new VeiculoBean(result.getInt(1), result.getInt(2), result.getInt(3),result.getString(4),result.getString(5),result.getString(6),result.getString(7),result.getString(8)));
            }
        return list;
    }
}

